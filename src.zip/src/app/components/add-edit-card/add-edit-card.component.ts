import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-add-edit-card',
  templateUrl: './add-edit-card.component.html',
  styleUrls: ['./add-edit-card.component.scss']
})
export class AddEditCardComponent implements OnInit {

  constructor() { }

  openCard:boolean=false;

  newData=
  {
    'data':'',
    'title':'',
  }

  @Input() addBoard?:boolean;

  @Input() boardId?:number;

  @Input() cardId?:number;
  
  @Input() cardData?;
  
  @Output() sendNewData=new EventEmitter();

  @Output() cardStatus=new EventEmitter();

  ngOnInit(): void {

    if(this.cardData){
      this.newData={'data':this.cardData.data,'title':this.cardData.title}
    }
    
  }

  cancelData(){
    this.cardStatus.emit(false);
  }

  sendData(){
    this.sendNewData.emit({boardId:this.boardId,cardId:this.cardId,"newData":this.newData});
  }

}
