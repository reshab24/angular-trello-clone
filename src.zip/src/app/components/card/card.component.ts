import { Component, Input, OnInit } from '@angular/core';
import { cardType } from 'src/app/interfaces/boardTypes';
import { MorkService } from 'src/app/services/mork.service';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
  editId: number;
  constructor(private mkService:MorkService) { }

  @Input() cardData:cardType;
  @Input() boardId:number;
  
  ngOnInit(): void {
  }

  editCardData(id){
    this.editId=id;
    // this.cardData
  }

  deleteCardData(cardId:number,boardId:number){
    this.mkService.deleteCard(cardId,boardId);
  }

  editData({boardId,newData,cardId}){
    this.mkService.editCardData(cardId,boardId,newData);
  }



}
