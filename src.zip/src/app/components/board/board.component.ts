import { moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { boardData } from 'src/app/interfaces/boardTypes';
import { MorkService } from 'src/app/services/mork.service';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.scss']
})
export class BoardComponent implements OnInit {

  openCard:boolean=false;

  constructor( private mkService:MorkService) { }

  @Input() boardData:boardData;


  ngOnInit(): void {

  }

  addData(){
    this.openCard=this.openCard?false:true;
  }

  cancelData(){
    this.openCard=false;
  }

  saveData({boardId,newData}){
    this.mkService.addCardToBoard(boardId,newData);
  }


  drop(event){
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      console.log('Transfering item to new container')
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  }

}
