import { Injectable } from '@angular/core';
import { from, of } from 'rxjs';
import { boardData } from '../interfaces/boardTypes';

@Injectable({
  providedIn: 'root'
})
export class MorkService {

  data:boardData []=
  [
    {
    id:1,
    heading:'To Do',
    cards:[
      {
        id:1,
        title:"Landing page",
        data:"Update personal website header background image"
      },
      {
        id:2,
        title:"Icon",
        data:"Update icons "
      },
      {
        id:3,
        title:"Routing",
        data:"Add Routing "
      },
      {
        id:4,
        title:"Header issue",
        data:"Header responsive issues"
      }
    ]
    },
    {
      id:2,
      heading:'Doing',
      cards:[
        {
          id:1,
          title:"alert",
          data:"Update personal website header background image"
        },
        {
          id:2,
          title:"alert",
          data:"CSS Flexbox"
        },
      ]
    },
]

  constructor() {

   }

   getBoardsData(){
    return of(this.data);
   }

   addCardToBoard(id:number,{data,title}){
    this.data.find(res=>res.id===id).cards.push({'id':Math.floor(Math.random() * 1000) + 1,'data':data,'title':title})
   }

   addNewBoard(boardHeading:string){
     const boardLength= this.data.length;
     this.data.push({'id':boardLength+1,'heading':boardHeading,'cards':[]})
   }

   deleteCard(cardId:number,boardId:number){
    this.data.find(res=>res.id===boardId).cards.splice(cardId-1,1);
   }

   editCardData(cardId:number,boardId:number,newData:{title:string,data:string}){


    
  let cardData=this.data.find(({id})=>id===boardId).cards
   .map((res)=>{
     if(res.id==cardId){
       return {...newData,id:res.id};
      }
     else{
       return res;
     }
    })

    this.data.find(({id})=>id===boardId).cards=cardData

   }
   
}
